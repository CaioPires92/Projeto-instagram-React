export default function Users() {
  return (
    <div className="usuario">
      <img src="assets/img/smallcutecats.svg" alt="smallcutecats" />
      <div className="texto">
        <div className="nome">smallcutecats</div>
        <div className="razao">Segue você</div>
      </div>
    </div>
  )
}
